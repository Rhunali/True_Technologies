package movie_booking;

import java.util.Scanner;

public class movies {
    private String name;
    private String theatername;
    private int noofticket;
    private int cost;

    movies() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter The Name of the movie: ");
        this.name = sc.nextLine();

        System.out.println("Enter The Theaters Name: ");
        this.name = sc.nextLine();

        System.out.println("Enter The No. Of Ticket: ");
        this.name = sc.nextLine();

        System.out.println("Enter The Cost Per Ticket: ");
        this.name = sc.nextLine();
    }

    void setName(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }

    void settheatername(String theatername) {
        this.theatername = theatername;
    }

    String gettheatername() {
        return theatername;
    }

    void setnoofticket(String noofticket) {
        this.noofticket = noofticket;
    }

    String getnoofticket() {
        return noofticket;
    }

    void setcost(int cost) {
        this.cost = cost;
    }

    int getcost() {
        return cost;
    }

    void storeAllDetails(String name, String brand, int memory, int camera, double price) {
        this.name = name;
        this.theatername = theatername;
        this.noofticket = noofticket;
        this.cost = cost;
    }

    void viewAllDetails() {
        System.out.println("Name :" + name);
        System.out.println("Theater Name:" + theatername);
        System.out.println("Number of Tickets :" + noofticket);
        System.out.println("Cost of the Ticket:" + cost);

    }
}
